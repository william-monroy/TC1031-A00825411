//
//  Datos.h
//  Act 3-4
//
//  Created by Maria Teresa Angulo Tello on 25/10/20.
//

#pragma once

struct Datos {
    string mes;
    string dia;
    string hrs;
    string min;
    string seg;
    string ip;
    string error;
    
    string clave;
    bool operator<(Datos);
    bool operator<=(Datos);
    bool operator>(Datos);
};

bool Datos::operator<(Datos dato){
    if (ip < dato.ip)
        return true;
    return false;
}

bool Datos::operator<=(Datos dato){
    if (ip <= dato.ip)
        return true;
    return false;
}

bool Datos::operator>(Datos dato){
    if (ip > dato.ip)
        return true;
    return false;
}
