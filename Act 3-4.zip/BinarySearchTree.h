//
//  BinarySearchTree.h
//  EstructurasDatos
//
//  Created by Maria Teresa Angulo Tello on 23/10/20.
//

// Nota: Ya se que hay muchos comentarios!! Perdone, me sirven para no perderme.
// En la proxima entrega tratare de no usarlos tanto

#ifndef BinarySearchTree_h
#define BinarySearchTree_h
#include "Node.h"
#include "Queue.h"
#include "Stack.h"
using namespace std;

template <class T>
class BST{
private:
    node<T>* root;
    void printTree(node<T>* data, int level);   // done
    void preOrder(node<T>*);                    // done
    void inOrder(node<T>*);                     // done
    void postOrder(node<T>*);                   // done
    void levelByLevel();                        // done
    int heightTree(node<T>*);                   // done
    
public:
    BST();
    void insert(T data);                // Listo
    void deleteData(T data);            // Listo
    void print();                       // Listo
    bool find(T data);                  // Listo
    int howManyChildren(node<T>*);      // Listo
    void visit(int);                    // Listo
    int height();                       // Listo
    void ancestors(T);                  // Listo
    int whatLevelAmI(T);                // Listo
};

template <class T>
BST<T>::BST(){
    root = NULL;
}

template <class T>
void BST<T>::insert(T data){
    // Si el arbol esta vacio, crea un nodo raiz
    if (root == NULL)
        root = new node<T>(data);
    // En caso de que el arbol no este vacio
    else{
        // Se crea un nodo auxiliar para apoyar con el borrado
        node<T>* aux = root;
        // Mientras el auxiliar sea diferente de uno, se ira descendiendo por el arbol
        while (aux != NULL) {
            // Si el dato a insertar es menor, se tiene que enfocar en los nodos left del aux
            if (data < aux->data){
                // Si el nodo izq es diferente de nulo, aux pasa a aux izq
                if (aux->left != NULL)
                    aux = aux->left;
                // Si el nodo izq es nulo, se crea un nuevo nodo en esa posicion y se sale del ciclo
                else{
                    aux->left = new node<T>(data);
                    return;
                }
            }
            // Este else describe el mismo comportamiento, pero para el lado izq
            else{
                if(aux->right != NULL)
                    aux = aux->right;
                else{
                    aux->right = new node<T>(data);
                    return;
                }
            }
        }
    }
}

template <class T>
void BST<T>::deleteData(T data){
    if (root != NULL){
        node<T>* aux = root;
        node<T>* prev = aux;
        while (aux != NULL){
            if (data < aux->data){
                prev = aux;
                aux = aux->left;
            }
            else if (data > aux->data){
                prev = aux;
                aux = aux->right;
            }
            else{
                if (howManyChildren(aux) == 0){
                    if (aux == root){
                        delete aux;
                        root = NULL;
                    }
                    else{
                        if (data < prev->data){
                            prev->left = NULL;
                        }
                        else if (data > prev->data){
                            prev->right = NULL;
                        }
                        delete aux;
                    }
                    return;
                }
                else if (howManyChildren(aux) == 1){
                    if (aux == root){
                        if (root->left != NULL)
                            root = root->right;
                        else
                            root = root->left;
                    }
                    else{
                        if (data < prev->data){
                            if (aux->left != NULL)
                                prev->left = aux->left;
                            else
                                prev->left = aux->right;
                        }
                        else{
                            if (aux->left != NULL)
                                prev->right = aux->left;
                            else
                                prev->right = aux->right;
                        }
                    }
                    delete aux;
                    return;
                }
                else if (howManyChildren(aux) == 2){
                    prev = aux;
                    node<T>* max = aux->left;
                    if (max->right == NULL){
                        aux->data = max->data;
                        prev->left = max->left;
                        delete max;
                    }
                    else{
                        while(max->right != NULL){
                            prev = max;
                            max = max->right;
                        }
                        aux->data = max->data;
                        prev->right = max->left;
                        delete max;
                    }
                }
            }
        }
    }
}

template <class T>
bool BST<T>::find(T data){
    if (root != NULL){
        node<T>* aux = root;
        while (aux != NULL){
            if (data < aux->data)
                aux = aux->left;
            else if (data > aux->data)
                aux = aux->right;
            else
                return true;
        }
    }
    return false;
}

// Cuenta los hijos del nodo ingresado
template <class T>
int BST<T>::howManyChildren(node<T>* node){
    int children = 0;
    if (node->left != NULL) children++;
    if (node->right != NULL) children++;
    return children;
}

// Imprime el árbol
template<class T>
void BST<T>::printTree(node<T>* aux, int level) {
   if (aux != NULL) {
       printTree(aux->right, level + 1);
       for (int i=0; i < level; i++) {
           cout << "  ";
       }
       cout << aux->data << endl;
       printTree(aux->left, level + 1);
   }
}
                   
template<class T>
void BST<T>::print() {
    int level = 0;
    cout << endl;
    printTree(root, level);
    cout << endl;
}

template <class T>
void BST<T>::preOrder(node<T>* node){
    if (node != NULL){
        cout << node->data << " ";
        preOrder(node->left);
        preOrder(node->right);
    }
}

template <class T>
void BST<T>::inOrder(node<T>* node){
    if (node != NULL){
        inOrder(node->left);
        cout << node->data << " ";
        inOrder(node->right);
    }
}

template <class T>
void BST<T>::postOrder(node<T>* node){
    if (node != NULL){
        postOrder(node->left);
        postOrder(node->right);
        cout << node->data << " ";
    }
}

template <class T>
void BST<T>::ancestors(T data){
    if (root != NULL){
        node<T>* aux = root;
        Stack<T> stack;
        if (data != aux->data){
            while (data != aux->data){
                stack.push(aux->data);
                if (data < aux->data){
                    if (aux->left != NULL)
                        aux = aux->left;
                }
                else {
                    if (aux->right != NULL)
                        aux = aux->right;
                }
            }
            while (!stack.isEmpty()){
                try {
                    T data = stack.pop();
                    cout << data << " ";
                }
                catch (runtime_error& e){
                    cout << e.what() << endl;
                }
            }
        }
        else {
            cout << data << "no tiene ancestros" << endl;
        }
    }
    else
        cout << "El arbol esta vacio" << endl;
}

template <class T>
void BST<T>::levelByLevel(){
    if (root != NULL){
        Queue<node<T>*> queue;
        queue.enqueue(root);
        while(!queue.isEmpty()){
            node<T>* aux = queue.dequeue();
            cout << aux->data << " ";
            if (aux->left != NULL)
                queue.enqueue(aux->left);
            if (aux->right != NULL)
                queue.enqueue(aux->right);
        }
    }
}

template <class T>
int BST<T>::whatLevelAmI(T data){
    int lvl = 0;
    if (root != NULL){
        node<T>* aux = root;
        if (data != aux->data){
            while (aux->data != data){
                lvl++;
                if (data < aux->data){
                    if (aux->left == NULL)
                        return -1;
                    else aux = aux->left;
                }
                else{
                    if (aux->right == NULL)
                        return -1;
                    else aux = aux->right;
                }
            }
            return ++lvl;
        }
        return 1;
    }
    else return -1;
}

template <class T>
int BST<T>::heightTree(node<T>* node){
    int height = 0;
    int left, right;
    if (node != NULL){
        height++;
        left = heightTree(node->left);
        right = heightTree(node->right);
        if (left > right)
            height += left;
        else
            height += right;
    }
    return height;
}

template <class T>
int BST<T>::height(){
    return heightTree(root);
}

template <class T>
void BST<T>::visit(int op){
    if (op == 1)
        preOrder(root);
    else if (op == 2)
        inOrder(root);
    else if (op == 3)
        postOrder(root);
    else if (op == 4)
        levelByLevel();
    
}

#endif /* BinarySearchTree_h */
