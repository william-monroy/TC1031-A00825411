//
//  IPs.h
//  Act 3-4
//
//  Created by Maria Teresa Angulo Tello on 25/10/20.
//

#pragma once

struct IPs {
    string ip;
    int accesos;
    bool operator<(IPs);
    bool operator<=(IPs);
    bool operator>(IPs);
};

bool IPs::operator<(IPs dato){
if (ip < dato.ip)
    return true;
return false;
}

bool IPs::operator<=(IPs dato){
if (ip <= dato.ip)
    return true;
return false;
}

bool IPs::operator>(IPs dato){
if (ip > dato.ip)
    return true;
return false;
}


