//
//  Node.h
//  EstructurasDatos
//
//  Created by Maria Teresa Angulo Tello on 23/10/20.
//

#pragma once

template <class T>
struct node{
    T data;
    node<T>* left;
    node<T>* right;
    node<T>* next;
    node<T>* back;
    // constructor
    node(T data);
    // for linear structures
    node(T data, node<T>*);
    // for binary trees
    node(T data, node<T>*, node<T>*);
};

template <class T>
node<T>::node(T data){
    this->data = data;
    left = NULL;
    right = NULL;
    next = NULL;
    back = NULL;
}

template <class T>
node<T>::node(T data, node<T>* left, node<T>* right){
    this->data = data;
    this->left = left;
    this->left = right;
    next = NULL;
    back = NULL;
}

template <class T>
node<T>::node(T data, node<T>* next){
    this->data = data;
    this->next = next;
    left = NULL;
    right = NULL;
    back = NULL;
}
