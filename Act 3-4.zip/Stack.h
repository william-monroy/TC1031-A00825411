//
//  Stack.h
//  EstructurasDatos
//
//  Created by Maria Teresa Angulo Tello on 25/10/20.
//

#ifndef Stack_h
#define Stack_h
#include "Node.h"

template <class T>
class Stack {
private:
    int size;
    node<T>* top;
public:
    Stack();
    void push(T data);
    T pop();
    T getTop();
    int getSize();
    void clear();
    void print();
    bool isEmpty();
};

template <class T>
Stack<T>::Stack(){
    top = NULL;
}

template <class T>
void Stack<T>::push(T data){
    top = new node<T>(data, top);
    size++;
}

template <class T>
T Stack<T>::pop(){
    if (top != NULL){
        T data;
        node<T>* aux = top;
        data = aux->data;
        top = aux->next;
        size--;
        delete aux;
        return data;
    }
    throw runtime_error("La pila esta vacia");
    
}

template <class T>
T Stack<T>::getTop(){
    if (top != NULL){
        return top->data;
    }
    throw runtime_error("La pila esta vacia");
}

template <class T>
int Stack<T>::getSize(){
    return size;
}

template <class T>
void Stack<T>::clear(){
    if (size > 0){
        int n = 0;
        while (n < size){
            node<T> * aux = top;
            top = aux->next;
            delete aux;
            n++;
        }
        size = 0;
    }
}

template <class T>
void Stack<T>::print(){
    node<T>* aux = top;
    for (int i = 0; i < size; i++){
        cout << aux->data << " ";
        aux = aux->next;
    }
    cout << endl;
}

template <class T>
bool Stack<T>::isEmpty(){
    return top == NULL;
}


#endif /* Stack_h */
