//
//  Heap.h
//  EstructurasDatos
//
//  Created by Maria Teresa Angulo Tello on 25/10/20.
//

#ifndef Heap_h
#define Heap_h
#include "DoubleLinkedList.h"

template <class T>
class Heap {
private:
    DLL<T> heap;
    int size;
    void downSort(int);
    void swap(int, int);
public:
    Heap();
    Heap(DLL<T>);
    bool isEmpty();
    void print();
    T remove();
};

template <class T>
Heap<T>::Heap(){
    size = 0;
}

template <class T>
void Heap<T>::swap(int n1, int n2){
    T aux = heap.getData(n1);
    heap.getData(n1) = heap.getData(n2);
    heap.getData(n2) = aux;
}

template <class T>
void Heap<T>::downSort(int index){
    while (index >= 0){
        int pos = index;
        while (pos * 2 <= size){
            int son1 = pos * 2;
            int son2 = pos * 2 + 1;
            int max;
            if (son2 > size){
                max = son1;
            }
            else{
                if (heap[son1] > heap[son2])
                    max = son1;
                else
                    max = son2;
            }
            if (heap[max] > heap[pos]){
                swap(pos, max);
                pos = max;
            }
            else{
                pos = size;
            }
        }
        index--;
    }
}

template <class T>
Heap<T>::Heap(DLL<T> list){
    if (!list.isEmpty()){
        heap = list;
        size = heap.getSize() - 1;
        int pos = size / 2;
        downSort(pos);
    }
}

template <class T>
T Heap<T>::remove(){
    if (!isEmpty()){
        T aux = heap.getData(0);
        swap(0, size);
        heap.deleteLast();
        downSort(1);
        return aux;
    }
    else
        throw runtime_error("El heap está vacío");
}
    
    
template <class T>
void Heap<T>::print(){
    heap.print();
}


template <class T>
bool Heap<T>::isEmpty(){
    return size == 0;
}

// para eliminar, intercambiar el primer elemento con el último
// eliminamos el último elemento

// reacomodamos hacia abajo
// como un enqueue
// nodo / 2 se compara si es mayor a su padre o no


// para insertar, se ponen al final
// se reacomoda hacia arriba

#endif /* Heap_h */
