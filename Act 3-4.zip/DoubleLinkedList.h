//
//  DoubleLinkedList.h
//  Act2-3
//
//  Created by Maria Teresa Angulo Tello on 04/10/20.
//

#ifndef DoubleLinkedList_h
#define DoubleLinkedList_h
#include "Node.h"
#include "Queue.h"
using namespace std;

template <class T>
class DLL {
private:
    int size;
    node<T>* head;
    node<T>* tail;
public:
    DLL();
    // operadores
    void operator=(initializer_list<T> list);
    void operator=(DLL<T> list);
    T& operator[](int index);
    // func
    void addFirst(T);
    void addLast(T);
    T getData(int);
    void updateAt(int, T);   
    int findDataLow(T);
    int findDataSup(T);
    void clear();
    void sort(); // Merge
    void mergeSort(int, int);
    void merge(int, int, int);
    void print();
    int getSize();
    bool isEmpty();
    bool deleteAt(int);
    bool deleteLast();
};

template <class T>
DLL<T>::DLL(){
    size = 0;
    head = NULL;
    tail = NULL;
}


template<class T>
void DLL<T>::operator=(DLL<T> list) {
    clear();
    for (int i = 0 ; i < list.size; i++) {
        addLast(list[i]);
    }
}

template<class T>
void DLL<T>::operator=(initializer_list<T> list) {
    if (isEmpty()) {
        for (T i : list) {
            addLast(i);
        }
    } else {
        throw runtime_error("Error: DoublyLinkedList no esta vacia");
    }
}

template<class T>
T& DLL<T>::operator[](int index) {
    if (index >= 0 && index < size) {
        if (index <= (size / 2 )) {
            node<T>* aux = head;
            int i = 0;
            while (aux != NULL) {
                if (i == index) {
                    return aux->data;
                }
                aux = aux->next;
                i++;
            }
        } else {
            node<T>* aux = tail;
            int i = size;
            while (aux != NULL) {
                if (i == index) {
                    return aux->data;
                }
                aux = aux->back;
                i--;
            }
        }
    }
    throw out_of_range("Invalid position");
}

template <class T>
void DLL<T>::addFirst(T data){
    node<T> *n = new node<T>(data);
    if (size == 0){
        head = n;
        tail = n;
    }
    else{
        n->next = head;
        head->back = n;
        head = n;
    }
    size++;
}

template <class T>
void DLL<T>::addLast(T data){
    node<T> *n = new node<T>(data);
    if (size == 0){
        head = n;
        tail = n;
    }
    else{
        tail->next = n;
        n->back = tail;
        tail = n;
    }
    size++;
}

template <class T>
T DLL<T>::getData(int index){
    if (index >= 0 && index < size){
        if (index < size / 2){
            node<T>* aux = head;
            int pos = 0;
            while (aux != NULL){
                if (pos == index){
                    return aux->data;
                }
                aux = aux->next;
                pos++;
            }
        }
        else{
            node<T>* aux = tail;
            int pos = size;
            while (aux != NULL){
                if (pos == index){
                    return aux->data;
                }
                aux = aux->back;
                pos--;
            }
        }
    }
    throw out_of_range("Invalid position");
}

template <class T>
void DLL<T>::updateAt(int index, T data){
    if (index >= 0 && index < size){
        int pos;
        if (index < size / 2){
            pos = 0;
            if (pos == index){
                head->data = data;
                return;
            }
            else {
                node<T>* aux = head;
                while (aux != NULL){
                    if (pos == index){
                        aux->data = data;
                        return;
                    }
                    else{
                        aux = aux->next;
                    }
                    pos++;
                }
            }
        }
        else{
            pos = size;
            if (pos == index){
                tail->data = data;
                return;
            }
            else{
                node<T>* aux = tail;
                while (aux != NULL){
                    if (pos == index){
                        aux->data = data;
                        return;
                    }
                    else
                        aux = aux->back;
                    pos--;
                }
            }
        }
    }
    else{
        throw out_of_range("Invalid position");
    }
}

template <class T>
void DLL<T>::clear(){
    if (size>0){
        int n = 0;
        while (n < size){
            node<T>* aux = head;
            head = aux->next;
            delete aux;
            n++;
        }
        size = 0;
    }
}

template<class T>
bool DLL<T>::deleteLast(){
    if (!isEmpty()){
        node<T>* aux = tail;
        tail = tail->back;
        if (tail == NULL){ //if the list is emptied
            head = NULL;
        }
        delete aux;
        size--;
        return true;
    }
    else{
        return false;
    }
}

template<class T>
bool DLL<T>::deleteAt(int index) {
    if (index >= 1 && index <= size) {
        if (index == 1) {
            node<T>* aux = head;
            head = aux->next;
            head->back = NULL;
            delete aux;
            size--;
            if (head == NULL) {
                tail = NULL;
            }
            return true;
        } else {
            if (head->next != NULL) {
                node<T>* aux = head->next;
                node<T>* back = head;
                int i = 2;
                while (aux != NULL) {
                    if (i == index) {
                        back->next = aux->next;
                        if (aux->next != NULL) {
                            aux->next->back = back;
                        } else {
                            tail = back;
                        }
                        delete aux;
                        size--;
                        return true;
                    } else {
                        back = aux;
                        aux = aux->next;
                    }
                    i++;
                }
            }
        }
    }
    return false;
}

template<class T>
void DLL<T>::sort(){
    mergeSort(0,size-1);
}

template <class T>
void DLL<T> :: mergeSort(int inicio, int fin){
    if (inicio < fin){
        int mid = (inicio + fin)/2;
        mergeSort(inicio, mid);
        mergeSort(mid+1, fin);
        merge(inicio,mid,fin);
    }
}

template <class T>
void DLL<T>::merge(int inicio, int mid, int fin){
    Queue<T> Left;
    Queue<T> Right;
    
    int pos = inicio;
    int n1 = mid - inicio + 1;
    int n2 = fin - mid;
    int i, j;
    
    for (i = 0; i < n1; i++)
        Left.enqueue(getData(inicio + i));
    for (j = 0; j < n2; j++)
        Right.enqueue(getData(mid + 1 + j));
    i = 0;
    j = 0;
    
    while (i < n1 && j < n2) {
        if (Left.front().clave <= Right.front().clave) {
            updateAt(pos, Left.dequeue());
            i++;
        }
        else {
            updateAt(pos, Right.dequeue());
            j++;
        }
        pos++;
    }
    while (i < n1) {
        updateAt(pos, Left.dequeue());
        i++;
        pos++;
    }
    while (j < n2) {
        updateAt(pos, Right.dequeue());
        j++;
        pos++;
    }
}


template <class T>
void DLL<T>::print(){
    node<T>* aux = head;
    for (int i = 0; i < size; i++){
        cout << aux->data << " ";
        aux = aux->next;
    }
    cout << endl;
}

template <class T>
int DLL<T>::getSize(){
    return size;
}

template <class T>
bool DLL<T>::isEmpty(){
    return size == 0;
}

#endif /* DoubleLinkedList_h */
