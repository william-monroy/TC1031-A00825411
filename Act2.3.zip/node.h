//
//  node.h
//  Act2-3
//
//  Created by Maria Teresa Angulo Tello on 04/10/20.
//

#pragma once

template <class T>
struct node{
    T data;
    node<T>* next;
    node<T>* back;
    node(T data);
    node(T data, node<T>* next, node<T>* back);
};

template <class T>
node<T>::node(T data){
    this->data = data;
    next = NULL;
    back = NULL;
}


template <class T>
node<T>::node(T data, node<T>* next, node<T>* back){
    this->data = data;
    this->next = next;
    this->back = back;
}
