//
//  Queue.h
//  Act2-3
//
//  Created by Maria Teresa Angulo Tello on 07/10/20.
//

#ifndef Queue_h
#define Queue_h
#include "node.h"
using namespace std;

template <class T>
class Queue{
private:
    node<T>* head;
    node<T>* tail;
    int size;
public:
    Queue();
    T dequeue();
    void enqueue(T data);
    T front();
    T back();
    int getSize();
    void clear();
    void print();
};

template <class T>
Queue<T>::Queue(){
    size = 0;
    head = NULL;
    tail = NULL;
}

template <class T>
T Queue<T>::dequeue(){
    if (size > 0){
        T data = head->data;
        node<T>* aux = head;
        head = aux->next;
        delete aux;
        size--;
        if (size==0)
            tail = NULL;
        return data;
    }
    throw runtime_error("La cola está vacía");
}

template <class T>
void Queue<T>::enqueue(T data){
    if (size!= 0)
    {
        tail->next = new node<T>(data);
        tail = tail->next;
    }
    else
    {
        head = new node<T>(data);
        tail = head;
    }
    size++;
}
    

template <class T>
T Queue<T>::front(){
    if (size == 0)
        throw runtime_error("La cola esta vacia");
    else
        return head->data;
}

template <class T>
T Queue<T>::back(){
    if (size == 0)
        throw runtime_error("La cola esta vacia");
    else
        return tail->data;
}

template <class T>
int Queue<T>::getSize(){
    return size;
}

template <class T>
void Queue<T>::clear(){
    if (size>0){
        int n = 0;
        while (n < size){
            node<T>* aux = head;
            head = aux->next;
            delete aux;
            n++;
        }
        size = 0;
    }
}


template <class T>
void Queue<T>::print(){
    node<T>* aux = head;
    for (int i = 0; i < size; i++){
        cout << aux->data << " ";
        aux = aux->next;
    }
    cout << endl;
}

#endif /* Queue_h */
