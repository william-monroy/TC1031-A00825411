//
//  DoubleLinkedList.h
//  Act2-3
//
//  Created by Maria Teresa Angulo Tello on 04/10/20.
//

#ifndef DoubleLinkedList_h
#define DoubleLinkedList_h
#include "node.h"
#include "Queue.h"
using namespace std;

template <class T>
class DLL {
private:
    int size;
    node<T>* head;
    node<T>* tail;
public:
    DLL();
    void addFirst(T);
    void addLast(T);
    T getData(int);
    void updateAt(int, T);   
    int findData(T);
    void clear();
    void sort(); // Merge
    void mergeSort(int, int);
    void merge(int, int, int);
    void print();
    int getSize();
};

template <class T>
DLL<T>::DLL(){
    size = 0;
    head = NULL;
    tail = NULL;
}

template <class T>
void DLL<T>::addFirst(T data){
    node<T> *n = new node<T>(data);
    if (size == 0){
        head = n;
        tail = n;
    }
    else{
        n->next = head;
        head->back = n;
        head = n;
    }
    size++;
}

template <class T>
void DLL<T>::addLast(T data){
    node<T> *n = new node<T>(data);
    if (size == 0){
        head = n;
        tail = n;
    }
    else{
        tail->next = n;
        n->back = tail;
        tail = n;
    }
    size++;
}

template <class T>
T DLL<T>::getData(int index){
    if (index >= 0 && index < size){
        if (index < size / 2){
            node<T>* aux = head;
            int pos = 0;
            while (aux != NULL){
                if (pos == index){
                    return aux->data;
                }
                aux = aux->next;
                pos++;
            }
        }
        else{
            node<T>* aux = tail;
            int pos = size;
            while (aux != NULL){
                if (pos == index){
                    return aux->data;
                }
                aux = aux->back;
                pos--;
            }
        }
    }
    throw out_of_range("Invalid position");
}

template <class T>
void DLL<T>::updateAt(int index, T data){
    if (index >= 0 && index < size){
        int pos;
        if (index < size / 2){
            pos = 0;
            if (pos == index){
                head->data = data;
                return;
            }
            else {
                node<T>* aux = head;
                while (aux != NULL){
                    if (pos == index){
                        aux->data = data;
                        return;
                    }
                    else{
                        aux = aux->next;
                    }
                    pos++;
                }
            }
        }
        else{
            pos = size;
            if (pos == index){
                tail->data = data;
                return;
            }
            else{
                node<T>* aux = tail;
                while (aux != NULL){
                    if (pos == index){
                        aux->data = data;
                        return;
                    }
                    else
                        aux = aux->back;
                    pos--;
                }
            }
        }
    }
    else{
        throw out_of_range("Invalid position");
    }
}

template <class T>
int DLL<T>::findData(T data){
    int izq = 0;
    int der = size - 1;
    int mid = (izq + der) / 2;
    bool found = false;
    while (izq <= der && !found){
        mid = (izq + der) / 2;
        if(data < getData(mid)){
            der = mid - 1;
        }
        else{
            if (data > getData(mid)){
                izq = mid + 1;
            }
            else{
                if (data == getData(mid)){
                    found = true;
                }
            }
        }
    }
    if (found){
        return mid;
    }
    else throw runtime_error("not found");

}

template <class T>
void DLL<T>::clear(){
    if (size>0){
        int n = 0;
        while (n < size){
            node<T>* aux = head;
            head = aux->next;
            delete aux;
            n++;
        }
        size = 0;
    }
}

template<class T>
void DLL<T>::sort(){
    mergeSort(0,size-1);
}

template <class T>
void DLL<T> :: mergeSort(int inicio, int fin){
    if (inicio < fin){
        int mid = (inicio + fin)/2;
        mergeSort(inicio, mid);
        mergeSort(mid+1, fin);
        merge(inicio,mid,fin);
    }
}

template <class T>
void DLL<T>::merge(int inicio, int mid, int fin){
    Queue<T> Left;
    Queue<T> Right;
    
    int pos = inicio;
    int n1 = mid - inicio + 1;
    int n2 = fin - mid;
    int i, j;
    
    for (i = 0; i < n1; i++)
        Left.enqueue(getData(inicio + i));
    for (j = 0; j < n2; j++)
        Right.enqueue(getData(mid + 1 + j));
    i = 0;
    j = 0;
    
    while (i < n1 && j < n2) {
        if (Left.front().clave <= Right.front().clave) {
            updateAt(pos, Left.dequeue());
            i++;
        }
        else {
            updateAt(pos, Right.dequeue());
            j++;
        }
        pos++;
    }
    while (i < n1) {
        updateAt(pos, Left.dequeue());
        i++;
        pos++;
    }
    while (j < n2) {
        updateAt(pos, Right.dequeue());
        j++;
        pos++;
    }
}


template <class T>
void DLL<T>::print(){
    node<T>* aux = head;
    for (int i = 0; i < size; i++){
        cout << aux->data << " ";
        aux = aux->next;
    }
    cout << endl;
}

template <class T>
int DLL<T>::getSize(){
    return size;
}

#endif /* DoubleLinkedList_h */
