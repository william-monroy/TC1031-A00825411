//
//  main.cpp
//  Act1-3
//
//  Created by Maria Teresa Angulo Tello on 10/09/20.
//  Copyright © 2020 Maria Teresa Angulo Tello. All rights reserved.
//

#include <iostream>
#include <stdlib.h>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "DoubleLinkedList.h"

using namespace std;

struct Datos {
    string mes;
    string dia;
    string hrs;
    string min;
    string seg;
    string ip;
    string error;
    
    string clave;
    bool operator<(Datos);
    bool operator<=(Datos);
};

bool Datos::operator<(Datos dato){
    if (clave < dato.clave)
        return true;
    return false;
}

bool Datos::operator<=(Datos dato){
    if (clave <= dato.clave)
        return true;
    return false;
}
/*
int buscarMenor(DLL<string> datos, string clave){
    if (clave < datos.getData(0))
        return 0;
    if (clave > datos.getData(datos.getSize() - 1))
        return -2;
    int low, mid, sup;
    low = 0;
    sup = datos.getSize();
    while (low <= sup){
        mid = (low + sup) / 2;
        if (clave == datos.getData(mid) || (clave < datos.getData(mid) && clave > datos.getData(mid-1)))
            return mid;
        else if(clave > datos.getData(mid) && clave < datos.getData(mid+1))
            return mid + 1;
        else if (clave < datos.getData(mid))
            sup = mid - 1;
        else
            low = mid + 1;
    }
    return -1;
}

int buscarMayor(DLL<string> datos, string clave){
    if (clave < datos.getData(0))
        return -2;
    if (clave > datos.getData(datos.getSize() - 1))
        return datos.getSize()-1;
    int low, mid, sup;
    low = 0;
    sup = datos.getSize();
    while (low <= sup){
        mid = (low + sup) / 2;
        if (clave == datos.getData(mid) || (clave > datos.getData(mid) && clave < datos.getData(mid+1)))
            return mid;
        else if (clave < datos.getData(mid) && clave > datos.getData(mid-1))
            return mid - 1;
        else if (clave < datos.getData(mid))
            sup = mid - 1;
        else
            low = mid + 1;
    }
    return -1;
}
*/
string createString(Datos data){
    if (data.dia.length() == 1)
        data.dia = "0" + data.dia;
    if (data.hrs.length() == 1)
        data.hrs = "0" + data.hrs;
    string sData = data.mes + data.dia + data.hrs + data.min + data.seg;
    return sData;
}

void printBitacora(DLL<Datos> info, int i){
    cout << info.getData(i).mes << " ";
    cout << info.getData(i).dia << " ";
    cout << info.getData(i).hrs << ":";
    cout << info.getData(i).min << ":";
    cout << info.getData(i).seg << " ";
    cout << info.getData(i).ip << " ";
    cout << info.getData(i).error << endl;
}

void monthToNum(string &mes){
    if (mes == "Jan")
        mes = "01";
    else if (mes == "Feb")
        mes = "02";
    else if (mes == "Mar")
        mes = "03";
    else if (mes == "Apr")
        mes = "04";
    else if (mes == "May")
        mes = "05";
    else if (mes == "Jun")
        mes = "06";
    else if (mes == "Jul")
        mes = "07";
    else if (mes == "Aug")
        mes = "08";
    else if (mes == "Sep")
        mes = "09";
    else if (mes == "Oct")
        mes = "10";
    else if (mes == "Nov")
        mes = "11";
    else if (mes == "Dic")
        mes = "12";
}

void numToMonth(string &mes){
    if (mes == "01")
        mes = "Jan";
    else if (mes == "02")
        mes = "Feb";
    else if (mes == "03")
        mes = "Mar";
    else if (mes == "04")
        mes = "Apr";
    else if (mes == "05")
        mes = "May";
    else if (mes == "06")
        mes = "Jun";
    else if (mes == "07")
        mes = "Jul";
    else if (mes == "08")
        mes = "Aug";
    else if (mes == "09")
        mes = "Sep";
    else if (mes == "10")
        mes = "Oct";
    else if (mes == "11")
        mes = "Nov";
    else if (mes == "12")
        mes = "Dec";
}

void readInput(Datos &data, string fecha){
    stringstream s(fecha);
    getline(s, data.mes, ' ');
    getline(s, data.dia, ' ');
    getline(s, data.hrs, ':' );
    getline(s, data.min, ':' );
    getline(s, data.seg, ' ' );
    monthToNum(data.mes);
}

void leerArchivo(DLL<Datos>& bitacora, DLL<string>& datos){
    Datos info;
    string data;
    int i = 0;
    ifstream archivo("bitacora.txt");
    if (archivo.fail()){
        cout << "El archivo no se ha leido" << endl;
        exit(1);
    }
    while (!archivo.eof()){
        getline(archivo, info.mes, ' ');
        getline(archivo, info.dia, ' ');
        getline(archivo, info.hrs, ':' );
        getline(archivo, info.min, ':' );
        getline(archivo, info.seg, ' ' );
        getline(archivo, info.ip, ' ' );
        getline(archivo, info.error);
        // Crear claves para facilitar el ordenamiento de los datos
        monthToNum(info.mes);
        data = createString(info);
        datos.addLast(data);
        numToMonth(info.mes);
        info.clave = data;
        // Guardar los structs de los datos en una Lista Encadenada
        bitacora.addLast(info);
    }
    archivo.close();
}

void outputArchivo(DLL<Datos> info){
    ofstream salida("bitacoraSalida.txt");
    if (salida.fail()){
        cout << "El archivo no se ha creado correctamente" << endl;
        exit(1);
    }
    for (int i = 0; i < info.getSize(); i++){
        salida << info.getData(i).mes << " ";
        salida << info.getData(i).dia << " ";
        salida << info.getData(i).hrs << ":";
        salida << info.getData(i).min << ":";
        salida << info.getData(i).seg << " ";
        salida << info.getData(i).ip << " ";
        salida << info.getData(i).error << endl;
    }
    salida.close();
}

int main(){
    Datos bajo, alto;
    DLL<Datos> listaBitacora;
    DLL<string> clave;
    string rangoBajo, rangoAlto;
    int indiceBajo, indiceAlto, tam;
    char op = 'C';
    
    cout << "Leyendo archivo..." << endl;
    // Importar los datos del archivo, ordenarlos y exportarlos
    leerArchivo(listaBitacora, clave);
    tam = listaBitacora.getSize() - 1;
    cout << "Archivo leído" << endl;
    cout << endl;
    cout << "Ordenando lista..." << endl;
    listaBitacora.sort();
    //mergeSort(listaBitacora, clave, 0, tam);
    cout << "Lista ordenada" << endl;
    cout << endl;
    cout << "Exportando lista..." << endl;
    outputArchivo(listaBitacora);
    cout << "Lista exportada" << endl;
    cout << endl;
    
    // Pedirle al usuario un rango de busqueda
    cout << "Introduzca el rango para su busqueda" << endl;
    do {
        cout << "Ejemplo de formato: " << endl;
        cout << "Aug 6 23:17:56" << endl;
        cout << "Fecha de inicio: " << endl;
        getline(cin, rangoBajo);
        readInput(bajo, rangoBajo);
        rangoBajo = createString(bajo);
        cout << "Fecha de fin: " << endl;
        getline(cin, rangoAlto);
        readInput(alto, rangoAlto);
        rangoAlto = createString(alto);
        if (rangoBajo > rangoAlto){
            cout << "\nEl rango es invalido. Introduzca la fecha mas antigua primero" << endl;
        }
    } while (rangoBajo > rangoAlto);
    
    // Buscar los índices de las claves que delimitan el rango
    indiceBajo = clave.findData(rangoBajo);
    indiceAlto = clave.findData(rangoAlto);
    
    // Desplegar los resultados de la busqueda
    if (indiceBajo == -2 || indiceAlto == -2) {
        cout << "\nNo se han encontrado datos" << endl;
    }
    else {
        cout << "\nSe han encontrado " << (indiceAlto - indiceBajo + 1) << " datos\n" << endl;
        while ((op == 'C' || op == 'c') && indiceBajo <= indiceAlto){
            for (int i = 0; i < 20 && indiceBajo <= indiceAlto; i++){
                printBitacora(listaBitacora, indiceBajo++);
            }
            if (indiceBajo <= indiceAlto){
                cout << "\nPresione C para continuar visualizando los datos" << endl;
                cout << "Presione X para salir" << endl;
                cin >> op;
            }
        }
    }
    return 0;
}
